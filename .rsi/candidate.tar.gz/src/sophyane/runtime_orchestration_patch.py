
"""Execution recovery helpers shared by current and older Sophyane TUIs."""
from __future__ import annotations

from sophyane.environment_constraints import (
    constraint_for_command,
    learn_constraints_from_result,
)

import os
import hashlib
import time
import uuid
from pathlib import Path
from typing import Any


_SNAPSHOT_EXCLUDED_PARTS = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".mypy_cache",
        ".ruff_cache",
        ".tox",
        ".nox",
        "node_modules",
    }
)

_SNAPSHOT_EXCLUDED_SUFFIXES = (
    ".pyc",
    ".pyo",
)

_SNAPSHOT_MAX_HASHED_BYTES = 128 * 1024 * 1024
_SNAPSHOT_MAX_FILE_BYTES = 16 * 1024 * 1024
_SNAPSHOT_READ_CHUNK_BYTES = 1024 * 1024


def _snapshot(root: Path) -> dict[str, str]:
    """Return bounded hashes for durable workspace files only.

    Directory pruning happens before traversal. File contents are streamed,
    and large/over-budget files receive stable metadata fingerprints so the
    learner can still detect changes without freezing the interactive UI.
    """
    output: dict[str, str] = {}
    root = Path(root).expanduser().resolve()
    if not root.exists():
        return output

    hashed_bytes = 0
    for directory, dirnames, filenames in os.walk(root, topdown=True):
        dirnames[:] = sorted(
            name for name in dirnames if name not in _SNAPSHOT_EXCLUDED_PARTS
        )
        filenames.sort()
        directory_path = Path(directory)

        for filename in filenames:
            if filename.endswith(_SNAPSHOT_EXCLUDED_SUFFIXES):
                continue
            path = directory_path / filename
            try:
                if path.is_symlink() or not path.is_file():
                    continue
                relative = path.relative_to(root).as_posix()
                stat = path.stat()
            except (OSError, ValueError):
                continue

            if (
                stat.st_size > _SNAPSHOT_MAX_FILE_BYTES
                or hashed_bytes + stat.st_size > _SNAPSHOT_MAX_HASHED_BYTES
            ):
                marker = f"large:{stat.st_size}:{stat.st_mtime_ns}".encode()
                output[relative] = hashlib.sha256(marker).hexdigest()
                continue

            digest = hashlib.sha256()
            try:
                with path.open("rb") as handle:
                    while chunk := handle.read(_SNAPSHOT_READ_CHUNK_BYTES):
                        digest.update(chunk)
            except OSError:
                continue
            output[relative] = digest.hexdigest()
            hashed_bytes += stat.st_size

    return output


def install_orchestration_patch() -> None:
    from sophyane import execution_runtime as runtime

    if getattr(runtime, "_orchestration_installed", False):
        return

    try:
        from sophyane import tui_v2
    except ImportError:
        tui_v2 = None

    if tui_v2 is not None and hasattr(tui_v2, "_execution_requested"):
        original_execution_requested = tui_v2._execution_requested

        def execution_requested(message: str) -> bool:
            # SOPHYANE_ORCHESTRATION_MAKE_USE_OF_CHAT_GUARD_V1
            #
            # The base TUI classifier intentionally treats conversational
            # "make use of ..." as chat. Preserve that decision here before
            # orchestration's broader execution heuristics are considered.
            _orchestration_guard_text = " ".join(
                str(message or "").casefold().split()
            )

            if (
                "make use of"
                in _orchestration_guard_text
                and not _orchestration_guard_text.startswith(
                    (
                        "make a ",
                        "make an ",
                        "make the ",
                        "make file ",
                        "make website ",
                        "make app ",
                        "make game ",
                    )
                )
            ):
                return False

            # Explicit imperative requests take precedence over a mistaken native
            # chat classification. This keeps requests such as "Create index.html"
            # inside the validated execution runtime.
            text = " ".join(message.lower().split())
            if original_execution_requested(message):
                return True
            try:
                from sophyane.native_kernel import classify
                native_mode = classify(message)
            except Exception:  # noqa: BLE001
                native_mode = None
            if native_mode == "execution":
                return True
            if native_mode == "chat":
                return False
            extra = (
                "diagnose", "debug", "giving error", "has error", "error in", "repair",
                "optimize", "profile", "audit", "integrate", "simulate", "benchmark",
                "self-improvement", "self improvement", "start a persistent", "monitor",
                "implement", "demonstrate", "apply reductions", "re-test", "retest",
            )
            return any(marker in text for marker in extra)

        tui_v2._execution_requested = execution_requested

        original_loop = tui_v2.run_structured_loop

        def learning_loop(
            *,
            initial_text: str,
            original_request: str,
            ask: Any,
            workspace: Path,
            max_steps: int,
            progress: Any,
        ) -> str:
            from sophyane.sli_learner import learn_execution
            from sophyane.sli_schema import ensure_current_schema

            before = _snapshot(workspace)
            started = time.monotonic()
            trace_id = uuid.uuid4().hex[:12]
            result = original_loop(
                initial_text=initial_text,
                original_request=original_request,
                ask=ask,
                workspace=workspace,
                max_steps=max_steps,
                progress=progress,
            )
            lowered = str(result).lower()
            failed = (
                lowered.startswith("execution loop failed")
                or lowered.startswith("stopped after bounded")
                or "failed safely" in lowered
            )
            try:
                ensure_current_schema()
                learned = learn_execution(
                    trace_id=trace_id,
                    request=original_request,
                    workspace_before=before,
                    workspace_after=_snapshot(workspace),
                    status="failed" if failed else "succeeded",
                    reward=-1.0 if failed else 1.0,
                    result=str(result),
                    elapsed_seconds=time.monotonic() - started,
                )
                progress(
                    "SLI recorded interactive execution "
                    f"{trace_id} reward={float(learned.get('quality_reward', 0.0)):+.2f}"
                )
            except Exception as error:  # noqa: BLE001
                progress(f"SLI recording skipped safely: {type(error).__name__}: {error}")
            return result

        tui_v2.run_structured_loop = learning_loop

    original_execute = runtime.execute_action

    def execute_action(action: dict[str, Any], workspace: Path, progress: Any) -> tuple[bool, str]:
        normalized = runtime._normalize_action(action) or action
        kind = str(normalized.get("type") or "").strip().lower()

        if kind in {"write_file", "append_file"}:
            path = str(normalized.get("path") or normalized.get("file") or "").strip()
            if not path:
                return False, "File action rejected: missing path. Return a concrete relative filename inside the workspace."
            target = (workspace / path).resolve()
            root = workspace.resolve()
            if target != root and root not in target.parents:
                return False, f"File action rejected: {path} is outside the active workspace. Use a relative path in {workspace}."

            content = str(
                normalized.get("content")
                or normalized.get("text")
                or ""
            )

            # Repair provider output that contains literal backslash-n text
            # rather than actual line breaks.
            if "\\n" in content and "\n" not in content:
                content = (
                    content
                    .replace("\\r\\n", "\n")
                    .replace("\\n", "\n")
                    .replace("\\t", "\t")
                )
                normalized = dict(normalized)
                normalized["content"] = content
                progress(f"Decoded escaped line breaks for {path}")

            if kind == "write_file" and target.exists():
                existing = target.read_text(
                    encoding="utf-8",
                    errors="replace",
                )

                if content == existing:
                    return True, (
                        f"File already matches requested content: {path} "
                        f"({target.stat().st_size} bytes)."
                    )

                # write_file is replacement, never an inferred continuation.
                temporary = target.with_name(
                    target.name + ".sophyane.tmp"
                )
                temporary.write_text(content, encoding="utf-8")
                temporary.replace(target)

                progress(
                    f"Atomically replaced {target} "
                    f"({len(existing)} -> {len(content)} characters)"
                )
                return True, (
                    f"Atomically replaced {target} "
                    f"({target.stat().st_size} total bytes)."
                )


        if kind in {"run", "shell", "run_command", "bash", "run_interactive", "interactive", "play_demo"}:
            command = str(normalized.get("command") or normalized.get("cmd") or normalized.get("content") or "").strip()
            if not command:
                return False, "Command action rejected: missing command. Return a concrete command or respond with completion."

            known_constraint = constraint_for_command(workspace, command)
            if known_constraint:
                return False, known_constraint

        try:
            ok, result = original_execute(normalized, workspace, progress)
        except (ValueError, OSError) as error:
            return False, f"Action rejected safely: {error}"

        if kind in {
            "run",
            "shell",
            "run_command",
            "bash",
            "run_interactive",
            "interactive",
            "play_demo",
        }:
            learn_constraints_from_result(
                workspace,
                command,
                result,
            )

        if not ok and result.startswith(
            "Repeated command blocked:"
        ):
            return False, (
                result
                + ". A repeated command is not proof of success. "
                  "Repair the project or run a distinct verification."
            )

        if not ok and result.startswith(
            "Repeated write_file blocked"
        ):
            return False, (
                result
                + ". Return a complete write_file replacement or an "
                  "explicit append_file continuation."
            )

        return ok, result

    runtime.execute_action = execute_action
    runtime._orchestration_installed = True
