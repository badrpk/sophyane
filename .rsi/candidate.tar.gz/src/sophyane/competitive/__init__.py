"""Competitive agent-OS surfaces."""
